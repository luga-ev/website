<TeXmacs|1.99.2>

<style|source>

<\body>
  <\active*>
    <\src-title>
      <src-style-file|beamer-extra|1.0>

      <\src-purpose>
        Footers and covers for the beamer style
      </src-purpose>

      <\src-copyright|2015>
        Miguel de Benito Delgado
      </src-copyright>

      <\src-license>
        This software falls under the <hlink|GNU general public license,
        version 3 or later|$TEXMACS_PATH/LICENSE>. It comes WITHOUT ANY
        WARRANTY WHATSOEVER. You should have received a copy of the license
        which the software. If not, see <hlink|http://www.gnu.org/licenses/gpl-3.0.html|http://www.gnu.org/licenses/gpl-3.0.html>.
      </src-license>
    </src-title>
  </active*>

  <use-package|beamer>

  <\active*>
    <\src-comment>
      Style parameters.

      The base-font-size = 10 is required for the adjustments to the position
      of the footer to work. It's hackish but gets the job done.
    </src-comment>
  </active*>

  <assign|screens-footer|>

  <assign|screens-footer-color|<value|title-bar-color>>

  <assign|font-base-size|10>

  <\active*>
    <\src-comment>
      Macro definitions.

      These macros should handle well changes in page size (e.g. from 4:3 to
      5:4 and so on), but are sensitive to changes in font size. To fix a
      misplaced bottom bar change its vertical shift (currently 2h - 1pag).

      <with|color|dark red|FIXME: Cursor movement is awkward/very hard inside
      both the cover and the slides title bar due to the shifts. It should be
      possible to set the drd-prop accessible=none in order to require
      deactivation of the tag to edit it but this seems not to work. The
      easiest workaround is to edit the source.>
    </src-comment>
  </active*>

  <assign|cover|<\macro|title|author|sub-left|sub-right>
    <\with|par-par-sep|0fn|par-sep|0fn|par-ver-sep|0fn|par-line-sep|0fn>
      <with|color|<value|tit-border-color>|<resize|<tabular*|<tformat|<twith|table-width|1par>|<twith|table-hmode|exact>|<cwith|1|1|1|-1|cell-background|<title-bar-color>>|<cwith|1|1|1|1|cell-halign|c>|<cwith|1|1|1|1|cell-hyphen|t>|<twith|table-valign|T>|<twith|table-vmode|auto>|<cwith|1|1|1|1|cell-bborder|5px>|<cwith|1|1|1|1|cell-height|0.2pag>|<cwith|1|1|1|1|cell-vmode|exact>|<cwith|1|1|1|1|cell-valign|c>|<table|<row|<\cell>
        <with|color|<title-color>|math-color|<title-color>|font-series|bold|font-size|1.5|<htab|5mm><arg|title><htab|5mm>>
      </cell>>>>>||0em||>>

      <shift|<with|color|<value|tit-border-color>|<tabular*|<tformat|<twith|table-width|1par>|<twith|table-hmode|exact>|<cwith|1|1|1|-1|cell-background|<screens-footer-color>>|<cwith|1|1|1|1|cell-halign|c>|<cwith|1|1|1|1|cell-hyphen|t>|<twith|table-valign|b>|<twith|table-height|0.02pag>|<twith|table-vmode|exact>|<cwith|1|1|1|1|cell-tsep|0em>|<cwith|1|1|1|1|cell-bsep|0em>|<cwith|1|1|1|1|cell-tborder|5px>|<table|<row|<\cell>
        <with|color|<title-color>|math-color|<title-color>|font-size|0.59|<arg|sub-left><htab|5mm><arg|sub-right>>
      </cell>>>>>>|0mm|<minus|2h|1pag>>

      <shift|<small|<strong|<arg|author>>>|<minus|0.5par|0.5w>|<minus|0.5pag>>
    </with>
  </macro>>

  <assign|tit|<\macro|head>
    <\with|par-left|<minus|<value|page-screen-left>>|par-right|<minus|<value|page-screen-right>>|par-par-sep|0fn|par-sep|0fn|par-ver-sep|0fn|par-line-sep|0fn>
      <shift|<with|color|<value|tit-border-color>|<resize|<tabular*|<tformat|<twith|table-width|1par>|<twith|table-hmode|exact>|<cwith|1|1|1|-1|cell-background|<title-bar-color>>|<cwith|1|1|1|1|cell-halign|c>|<cwith|1|1|1|1|cell-hyphen|t>|<cwith|2|2|1|1|cell-vcorrect|n>|<cwith|2|2|1|1|cell-halign|l>|<twith|table-valign|T>|<cwith|2|2|1|1|cell-valign|t>|<cwith|2|2|1|1|cell-height|0.6fn>|<cwith|2|2|1|1|cell-vmode|exact>|<twith|table-vmode|auto>|<cwith|1|1|1|1|cell-height|0.05pag>|<cwith|1|1|1|1|cell-vmode|exact>|<cwith|1|1|1|1|cell-bborder|5px>|<table|<row|<\cell>
        <with|color|<title-color>|math-color|<title-color>|font-series|bold|<title-left|<arg|head>><htab|5mm><arg|head><htab|5mm>>
      </cell>>|<row|<cell|<with|locus-color|grey|opacity|100%|<tiny|<screens-bar|<quote-arg|head>>>>>>>>>||0em||>>|0mm|<value|page-screen-top>>

      <shift|<with|color|<value|tit-border-color>|<tabular*|<tformat|<twith|table-width|1par>|<twith|table-hmode|exact>|<cwith|1|1|1|-1|cell-background|<screens-footer-color>>|<cwith|1|1|1|1|cell-halign|c>|<cwith|1|1|1|1|cell-hyphen|t>|<twith|table-valign|b>|<twith|table-height|0.02pag>|<twith|table-vmode|exact>|<cwith|1|1|1|1|cell-tsep|0em>|<cwith|1|1|1|1|cell-bsep|0em>|<cwith|1|1|1|1|cell-tborder|5px>|<table|<row|<\cell>
        <with|color|<title-color>|math-color|<title-color>|font-size|0.59|<screens-footer><htab|5mm><title-right|<arg|head>>>
      </cell>>>>>>|0mm|<minus|1h|1pag>>
    </with>
  </macro>>
</body>

<initial|<\collection>
</collection>>