<map version="freeplane 1.12.1">
<!--To view this file, download free mind mapping software Freeplane from https://www.freeplane.org -->
<node LOCALIZED_STYLE_REF="AutomaticLayout.level.root" FOLDED="false" ID="ID_1090958577" CREATED="1409300609620" MODIFIED="1745514737756"><richcontent TYPE="NODE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Einführung in
    </p>
    <p>
      das Fediverse
    </p>
    <p>
      <span style="font-size: 40pt;">⁂</span>
    </p>
  </body>
</html>
</richcontent>
<hook NAME="accessories/plugins/AutomaticLayout.properties" VALUE="ALL"/>
<font SIZE="20" BOLD="true"/>
<hook NAME="MapStyle" background="#ffffffff" zoom="0.513158">
    <properties show_icon_for_attributes="true" edgeColorConfiguration="#808080ff,#ff0000ff,#0000ffff,#00ff00ff,#ff00ffff,#00ffffff,#7c0000ff,#00007cff,#007c00ff,#7c007cff,#007c7cff,#7c7c00ff" show_tags="UNDER_NODES" show_note_icons="true" associatedTemplateLocation="template:/light_nord_template.mm" fit_to_viewport="false" show_icons="BESIDE_NODES"/>
    <tags category_separator="::"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="bottom_or_right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" ID="ID_506805493" ICON_SIZE="12 pt" FORMAT_AS_HYPERLINK="false" COLOR="#484747" BACKGROUND_COLOR="#efefef" STYLE="bubble" SHAPE_HORIZONTAL_MARGIN="8 pt" SHAPE_VERTICAL_MARGIN="5 pt" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="1.9 px" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#8fbcbb" BORDER_DASH_LIKE_EDGE="true" BORDER_DASH="SOLID">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" DASH="" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_506805493" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<font NAME="SansSerif" SIZE="11" BOLD="false" STRIKETHROUGH="false" ITALIC="false"/>
<edge STYLE="bezier" COLOR="#2e3440" WIDTH="3" DASH="SOLID"/>
<richcontent TYPE="DETAILS" CONTENT-TYPE="plain/auto"/>
<richcontent TYPE="NOTE" CONTENT-TYPE="plain/auto"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#ffffff" BACKGROUND_COLOR="#2e3440" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="1.9 px" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#f0f0f0" BORDER_DASH_LIKE_EDGE="true">
<font SIZE="11" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.tags">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#000000" BACKGROUND_COLOR="#f6f9a1" TEXT_ALIGN="LEFT">
<icon BUILTIN="clock2"/>
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.selection" COLOR="#eceff4" BACKGROUND_COLOR="#bf616a" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#bf616a"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="bottom_or_right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.important" ID="ID_915433779" BORDER_COLOR="#bf616a">
<icon BUILTIN="yes"/>
<arrowlink COLOR="#bf616a" TRANSPARENCY="255" DESTINATION="ID_915433779"/>
<font NAME="Ubuntu" SIZE="14"/>
<edge COLOR="#bf616a"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.flower" COLOR="#ffffff" BACKGROUND_COLOR="#255aba" STYLE="oval" TEXT_ALIGN="CENTER" BORDER_WIDTH_LIKE_EDGE="false" BORDER_WIDTH="22 pt" BORDER_COLOR_LIKE_EDGE="false" BORDER_COLOR="#f9d71c" BORDER_DASH_LIKE_EDGE="false" BORDER_DASH="CLOSE_DOTS" MAX_WIDTH="6 cm" MIN_WIDTH="3 cm"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="bottom_or_right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#ffffff" BACKGROUND_COLOR="#484747" STYLE="bubble" SHAPE_HORIZONTAL_MARGIN="10 pt" SHAPE_VERTICAL_MARGIN="10 pt">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#eceff4" BACKGROUND_COLOR="#d08770" STYLE="bubble" SHAPE_HORIZONTAL_MARGIN="8 pt" SHAPE_VERTICAL_MARGIN="5 pt">
<font SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#3b4252" BACKGROUND_COLOR="#ebcb8b">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#2e3440" BACKGROUND_COLOR="#a3be8c">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#2e3440" BACKGROUND_COLOR="#b48ead">
<font SIZE="11"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#e5e9f0" BACKGROUND_COLOR="#5e81ac">
<font SIZE="11"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" BACKGROUND_COLOR="#81a1c1">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" BACKGROUND_COLOR="#88c0d0">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" BACKGROUND_COLOR="#8fbcbb">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" BACKGROUND_COLOR="#d8dee9">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" BACKGROUND_COLOR="#e5e9f0">
<font SIZE="9"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<node TEXT="Nicht nur in Diensten, sondern auch bei Veranstaltungen wie sie bei diesem Beitrag von Ückück beschrieben werden ..." POSITION="bottom_or_right" ID="ID_1695466929" CREATED="1744036917118" MODIFIED="1745513840857" LINK="https://gnulinux.ch/welche-veranstaltungen-gibt-es">
<icon BUILTIN="idea"/>
<node TEXT="... sondern auch bei Veranstaltungen wie sie bei diesem Beitrag von Ückück beschrieben werden ..." ID="ID_435737214" CREATED="1744036964879" MODIFIED="1744037148441" LINK="https://gnulinux.ch/welche-veranstaltungen-gibt-es">
<icon BUILTIN="idea"/>
</node>
<node TEXT="FediCamp" ID="ID_102207291" CREATED="1744036995936" MODIFIED="1744037031019"/>
<node TEXT="FediTreffs" ID="ID_1652907246" CREATED="1744037031882" MODIFIED="1744037034075"/>
<node TEXT="Fedivers Fachtage (z.B. Berlin)" ID="ID_236541012" CREATED="1744037034954" MODIFIED="1744037058764"/>
<node TEXT="Workshops" ID="ID_537724164" CREATED="1744037060051" MODIFIED="1744037063044"/>
<node TEXT="Sprechstunden" ID="ID_921393491" CREATED="1744037066075" MODIFIED="1744037074076"/>
<node TEXT="Moderations-Vernetzungen" ID="ID_1985646866" CREATED="1744037074843" MODIFIED="1744037093645"/>
<node TEXT="..." ID="ID_416599907" CREATED="1744037097828" MODIFIED="1744037100581"/>
</node>
<node TEXT="Geschichte des Fediverse" POSITION="top_or_left" ID="ID_413406671" CREATED="1745320895945" MODIFIED="1745320927511" LINK="https://gnulinux.ch/die-unvollstaendige-geschichte-des-fediverse">
<node TEXT="Federation &amp; Universe" POSITION="top_or_left" ID="ID_1906443564" CREATED="1745323893180" MODIFIED="1745323913325"/>
<node TEXT="Föderation, z.B. standardisiertes Kommunikationsprotokoll zw. verschiedenen Servern, Diensten, ..." POSITION="top_or_left" ID="ID_1510636871" CREATED="1744037270731" MODIFIED="1745413738381" LINK="https://en.wikipedia.org/wiki/Federation_(information_technology)">
<node TEXT="siehe z.B. auch Federated Sharing mit Nextcloud / ownCloud / Opencloud, Mailserver, ..." ID="ID_704420730" CREATED="1745413681222" MODIFIED="1745415306173"/>
<node TEXT="Protokolle im Fediverse" ID="ID_281739230" CREATED="1745415307652" MODIFIED="1745434281227">
<node TEXT="ActivityPub" ID="ID_195865315" CREATED="1745434142109" MODIFIED="1745434268079" LINK="https://de.wikipedia.org/wiki/ActivityPub"/>
<node TEXT="AT-Protokoll von Bluesky (nicht Fediverse!)" ID="ID_453191980" CREATED="1745434557308" MODIFIED="1745434616643" LINK="https://en.wikipedia.org/wiki/AT_Protocol"/>
</node>
</node>
<node TEXT="Dezentral" POSITION="top_or_left" ID="ID_1047228135" CREATED="1744037260114" MODIFIED="1745414759848">
<node TEXT="Eigene Knoten betreibbar. Freie Software" ID="ID_817618999" CREATED="1745414802265" MODIFIED="1745434095972"/>
<node TEXT="Gegenseitiges &quot;Finden&quot; über DNS-Einträge" ID="ID_1214206755" CREATED="1745415247450" MODIFIED="1745415281091"/>
</node>
<node TEXT="FediDB - Größe, User, Dienste, ... Ende April 2025" POSITION="top_or_left" ID="ID_852186515" CREATED="1745416264648" MODIFIED="1745424010752" LINK="https://fedidb.org/"/>
<node TEXT="Logo(s)" POSITION="top_or_left" ID="ID_1211177133" CREATED="1745428351431" MODIFIED="1745428355112">
<node TEXT="Pentagram mit Regenbogenfarben" ID="ID_82519350" CREATED="1745428356287" MODIFIED="1745428365584"/>
<node TEXT="Unicode-Zeichen &quot;asterism&quot; - U+2042 - ⁂" ID="ID_1138933760" CREATED="1745428366383" MODIFIED="1745428672335" LINK="https://symbol.fediverse.info/de"/>
</node>
</node>
<node TEXT="Gründe" POSITION="top_or_left" ID="ID_939773288" CREATED="1745508407734" MODIFIED="1745508412007">
<node TEXT="Kein zentrales Tracking" ID="ID_130213020" CREATED="1745508412990" MODIFIED="1745508420920"/>
<node TEXT="Keine &quot;Walled Gardens&quot;" POSITION="top_or_left" ID="ID_196105263" CREATED="1745434061498" MODIFIED="1745434071611"/>
<node TEXT="Vergleichsmatrix Mastodon, Bluesky, Threads, X der Kommunikationsagentur King Consult" POSITION="top_or_left" ID="ID_316315083" CREATED="1745514411263" MODIFIED="1745514511487" LINK="https://social-media-matrix.king-consult.de/"/>
<node TEXT="Keine zentrale Kontrolle, Zensur, Sperrung, ..." POSITION="top_or_left" ID="ID_88597738" CREATED="1745414172433" MODIFIED="1745486522217"/>
<node TEXT="#DigitaleSouveränität" ID="ID_171255148" CREATED="1745508635935" MODIFIED="1745508646488"/>
<node TEXT="#UnplugTrump, ganz generell aber hier Tipp 6 - https://www.kuketz-blog.de/empfehlungsecke/#fediverse" ID="ID_420990188" CREATED="1745508421719" MODIFIED="1745508623809" LINK="https://www.kuketz-blog.de/unplugtrump-mach-dich-digital-unabhaengig-von-trump-und-big-tech/"/>
</node>
<node TEXT="Wie einsteigen?" POSITION="top_or_left" ID="ID_732448950" CREATED="1744037278555" MODIFIED="1745415529889">
<node TEXT="Instanz finden / wählen" ID="ID_1059077897" CREATED="1745417031693" MODIFIED="1745417038646">
<node TEXT="Man kann später die Instanz auch wechseln" ID="ID_1261913407" CREATED="1745436287939" MODIFIED="1745483809565">
<icon BUILTIN="idea"/>
</node>
<node TEXT="https://joinmastodon.org/servers - wobei dort nicht alle verfügbaren Server gelistet sind" ID="ID_1969457866" CREATED="1745497901165" MODIFIED="1745497923647" LINK="https://joinmastodon.org/servers"/>
<node TEXT="Hat der Server eine einigermaßen aktuelle Software-Version" ID="ID_1574703954" CREATED="1745436317916" MODIFIED="1745436336150"/>
<node TEXT="Passt das Thema mal grundsätzlich zu mir - nur damit ich mich nicht schämen muss :-)" ID="ID_1421587172" CREATED="1745436354974" MODIFIED="1745436369311"/>
<node TEXT="Masseninstanz oder eher &quot;klein aber fein&quot;" ID="ID_1159760615" CREATED="1745436340717" MODIFIED="1745436351631"/>
</node>
<node TEXT="Account anlegen" ID="ID_1234948178" CREATED="1745417039333" MODIFIED="1745432449431">
<node TEXT="Vorher überlegen ob anonym ... bis voll als Person erkennbar gestaltet" ID="ID_667976315" CREATED="1745432465254" MODIFIED="1745432491168"/>
<node TEXT="&quot;Aufhübschen&quot;! Wie immer ist ein (zumindest thematisch) aussagekräftiges Profil ein guter Start - speziell wenn man Follower haben möchte. Hilfestellung über https://&lt;server-url&gt;/start" ID="ID_568600360" CREATED="1745432450038" MODIFIED="1745508312775" LINK="https://bildung.social/start"/>
</node>
<node TEXT="Accounts finden denen man erst mal folgt" ID="ID_1234612705" CREATED="1745417043789" MODIFIED="1745417065167">
<node TEXT="Erster Tröt / Toot in dem #Neuhier bzw. #introduction  stehen sollte." ID="ID_1577092113" CREATED="1745423557531" MODIFIED="1745436016098"/>
<node TEXT="Über &quot;Entdecken&quot; oder &quot;Live-Feeds (hier spielt dann evtl. die Instanz-Auswahl thematisch eine Rolle!" ID="ID_1680173909" CREATED="1745417071910" MODIFIED="1745500030438"/>
<node TEXT="Über Sichtung populärer Accounts, z.B. https://fedidb.org/popular-fediverse-accounts" ID="ID_1431704459" CREATED="1745417137329" MODIFIED="1745423487446" LINK="https://fedidb.org/popular-fediverse-accounts"/>
<node TEXT="Wer folgt wiederum diesen Accounts, wem folgen sie?" ID="ID_524880108" CREATED="1745436053523" MODIFIED="1745436066748"/>
<node TEXT="Gruppen folgen, z.B. Übersicht auf https://a.gup.pe/" ID="ID_234641070" CREATED="1745436204504" MODIFIED="1745436219006" LINK="https://a.gup.pe/"/>
<node TEXT="Über Ausschau halten nach z.B. dem Mastodon-Logo auf Websites, Blogs, ... oder in Vortragsfolien" ID="ID_52185577" CREATED="1745423494753" MODIFIED="1745423537188"/>
<node TEXT="Hash-Tags nach eigenem Interesse folgen, im Bildungsbereich z.B. #FediLZ" ID="ID_1180831909" CREATED="1745423544139" MODIFIED="1745436248339"/>
<node TEXT="&quot;Empfohlene Profile&quot; sichten (wird ggf. eingeblendet)" ID="ID_246952899" CREATED="1745500665677" MODIFIED="1745500692567"/>
</node>
<node TEXT="&quot;Direkter Ton&quot;" ID="ID_1141258349" CREATED="1745430410098" MODIFIED="1745430428947">
<node TEXT="Wird dem Fediverse generell nachgesagt" ID="ID_1821636893" CREATED="1745430440115" MODIFIED="1745430452172"/>
<node TEXT="z.B. bei fehlenden Bildbeschreibungen" ID="ID_1575698011" CREATED="1745430429690" MODIFIED="1745430439124"/>
<node TEXT="oder z.B. fehlenden Content Warnings (CW)" ID="ID_681312832" CREATED="1745430463228" MODIFIED="1745430472869"/>
<node TEXT="Besserwissende, Mansplaining, ..." ID="ID_294808271" CREATED="1745430781360" MODIFIED="1745430801353"/>
<node TEXT="Dickes Fell haben, nicht abschrecken lassen!" ID="ID_1360710136" CREATED="1745430802120" MODIFIED="1745430810490"/>
</node>
<node TEXT="Toots" ID="ID_1131801497" CREATED="1745432640213" MODIFIED="1745432643566">
<node TEXT="Selbst guten Ton einhalten" ID="ID_937272303" CREATED="1745432644421" MODIFIED="1745432648262"/>
<node TEXT="Und das ist das Internet! Öffentlich! Dauerhaft" ID="ID_261156586" CREATED="1745432649053" MODIFIED="1745432666903"/>
</node>
</node>
<node TEXT="Weiteres Material" POSITION="top_or_left" ID="ID_1538243924" CREATED="1744037884365" MODIFIED="1744037893862">
<node TEXT="Kolumne &quot;Ückück und das Fediverse&quot; (seit Mai 2024) für den Community-Blog GNU/Linux.ch mit 12 Episoden (Stand April 2025)" POSITION="top_or_left" ID="ID_215183421" CREATED="1744037658939" MODIFIED="1744038403035">
<node TEXT="Als Podcast-Episoden auf https://podcasts.homes/@ueckueck_und_das_fediverse" ID="ID_1049496479" CREATED="1744038227674" MODIFIED="1744038254968" LINK="https://podcasts.homes/@ueckueck_und_das_fediverse"/>
<node TEXT="Verlinkungen auf die Text-Version von gnulinux.ch sind unter https://ückück.com/kolumne-ueckueck-und-das-fediverse zu finden" ID="ID_1050414289" CREATED="1744038282876" MODIFIED="1744038329475" LINK="https://ückück.com/kolumne-ueckueck-und-das-fediverse"/>
</node>
<node TEXT="Fedi.Tips - An Unofficial Guide to Mastodon &amp; the Fediverse" ID="ID_2982485" CREATED="1745318602420" MODIFIED="1745318626753" LINK="https://fedi.tips/"/>
<node TEXT="Join the Fediverse Wiki" ID="ID_1029773358" CREATED="1745414599857" MODIFIED="1745414618798" LINK="https://joinfediverse.wiki/Main_Page"/>
<node TEXT="Fediverse.Party -&#xa;Explore Federated Networks" ID="ID_1550795911" CREATED="1745324129333" MODIFIED="1745324161979" LINK="https://fediverse.party/"/>
</node>
<node TEXT="Accounts, Server, Potential, ..." POSITION="top_or_left" ID="ID_257912849" CREATED="1744992741174" MODIFIED="1745431664060">
<node TEXT="Städte, z.B. die Stadt Friedrichshafen" ID="ID_1765925516" CREATED="1744992753918" MODIFIED="1745431770834" LINK="https://bawü.social/@Friedrichshafen"/>
<node TEXT="Augsburg und Umgebung" ID="ID_623918060" CREATED="1745493717473" MODIFIED="1745514790951" LINK="https://augsburg.social/explore"/>
<node TEXT="Schulen wie z.B. die Berufliche Schule ITECH (BS14) Hamburg" ID="ID_156821199" CREATED="1744992881603" MODIFIED="1745431762662" LINK="https://mastodon.schule/@BeruflicheSchuleITECH"/>
<node TEXT="Universitäten, Hochschulen, ... (Vorreiter Uni Innsbruck mit User-Directory Anbindung)" ID="ID_765584226" CREATED="1745484197666" MODIFIED="1745515799398"/>
<node TEXT="Fediverse Server der EU, des Bundes, der Länder, von Datenschutzbeauftragten (Mastodon, PeerTube) wie z.B. https://bawü.social bzw. https://tube.bawü.social des LfDIs Baden-Württemberg" ID="ID_692373369" CREATED="1745431668521" MODIFIED="1745484020044" LINK="https://bawü.social/directory"/>
<node TEXT="Reichweite" ID="ID_1252862154" CREATED="1745484404961" MODIFIED="1745484411869">
<icon BUILTIN="help"/>
<node TEXT="Auf &quot;klassischen&quot; Social Media werden Beiträge, Klicks auf Links, ... offenbar komplett überbewertet" ID="ID_177988031" CREATED="1745484430794" MODIFIED="1745484806713"/>
<node TEXT="Heise Online hat nach Eröffnung eines Accounts relativ zeitnah getrötet, dass die messbare Klickrate aus dem Fediverse schnell die klassischen Social Medias übetroffen hat." ID="ID_962961339" CREATED="1745484807896" MODIFIED="1745484884108"/>
<node TEXT="Aber wenn schon bei den anderen Medien, warum dann nicht noch den einen Zusatz-Account im Fediverse" ID="ID_1410627498" CREATED="1745509192723" MODIFIED="1745509249622">
<icon BUILTIN="idea"/>
</node>
</node>
</node>
<node TEXT="Server-Software/-Dienste (nur ein unvollständiger Auszug!) in unterschiedlichem Reifegrad" POSITION="bottom_or_right" ID="ID_738665901" CREATED="1745318048620" MODIFIED="1745497397348">
<node TEXT="Firefish (ehemals Calckey), ein Fork von Misskey" ID="ID_130937709" CREATED="1745318063912" MODIFIED="1745318311478" LINK="https://www.heise.de/hintergrund/Mehr-als-nur-Twitter-Kopie-Calckey-im-Fediverse-denkt-Social-Media-weiter-9205667.html"/>
<node TEXT="Mastodon" ID="ID_1479684284" CREATED="1745318325322" MODIFIED="1745318330163"/>
<node TEXT="Misskey" ID="ID_177172423" CREATED="1745318331290" MODIFIED="1745318333451"/>
<node TEXT="Friendica" ID="ID_1645294715" CREATED="1745320537627" MODIFIED="1745320544829"/>
<node TEXT="PeerTube (Videos,  ... vgl. YouTube)" ID="ID_1927131307" CREATED="1745318333970" MODIFIED="1745324334737"/>
<node TEXT="Lemmy (vgl. Reddit)" ID="ID_1826541474" CREATED="1745324308315" MODIFIED="1745324344318"/>
<node TEXT="BookWyrm (Bücher lesen, besprechen, ...)" ID="ID_313961320" CREATED="1745324371430" MODIFIED="1745324416520"/>
<node TEXT="Pixelfed (Instagram-Alternative?)" ID="ID_1719919197" CREATED="1745318336962" MODIFIED="1745485274962"/>
<node TEXT="Vernissage (für Fotografen)" ID="ID_1195173671" CREATED="1745485276217" MODIFIED="1745485380233"/>
<node TEXT="Castopod (für Podcasts), Vortrag von Stephanie Henkel (aka Ückück) auf den CLT25" ID="ID_1832443819" CREATED="1745485660007" MODIFIED="1745493451307" LINK="https://media.ccc.de/v/clt25-193-castopod-podcasting-im-fediverse"/>
<node TEXT="Funkwhale (für Musiker)" ID="ID_220320641" CREATED="1745320774364" MODIFIED="1745485549340"/>
<node TEXT="OwnCast (Live-Streaming, Twitch-Ersatz), Vortrag von Tobias Diekershoff auf den CLT25" ID="ID_709005795" CREATED="1745492477692" MODIFIED="1745493541661" LINK="https://media.ccc.de/v/clt25-238-fediverse-abseits-von-text-im-stream"/>
<node TEXT="Loops (neu?, als TikTok-Alternative?)" ID="ID_691973672" CREATED="1745319383368" MODIFIED="1745319402754"/>
</node>
<node TEXT="Mastodon-Clients / -Apps" POSITION="bottom_or_right" ID="ID_804779101" CREATED="1745319098422" MODIFIED="1745515677844" LINK="https://joinmastodon.org/apps">
<node TEXT="Desktop" ID="ID_1949496372" CREATED="1745515116834" MODIFIED="1745515123291">
<node TEXT="Web-Browser der Wahl ..." POSITION="bottom_or_right" ID="ID_1218345510" CREATED="1745319104062" MODIFIED="1745319927763">
<node TEXT="Erweiterte Ansicht - eine Deck-Ansicht" ID="ID_959922024" CREATED="1745493265096" MODIFIED="1745493912161"/>
<node TEXT="Schlankere, nicht erweitertete Ansicht" ID="ID_984915993" CREATED="1745493277801" MODIFIED="1745493326356"/>
</node>
</node>
<node TEXT="Android" ID="ID_73139481" CREATED="1745493331107" MODIFIED="1745493334524">
<node TEXT="Tusky" ID="ID_10835094" CREATED="1745493334851" MODIFIED="1745493337276"/>
<node TEXT="Fedilab" ID="ID_1225211959" CREATED="1745493342851" MODIFIED="1745493360197"/>
<node TEXT="Moshidon" ID="ID_1848737221" CREATED="1745513682603" MODIFIED="1745513691453"/>
<node TEXT="Mastodon" ID="ID_918406994" CREATED="1745493338203" MODIFIED="1745493340956"/>
</node>
<node TEXT="iOS/iPadOS" ID="ID_990575770" CREATED="1745493363684" MODIFIED="1745493371101">
<node TEXT="Ivory" ID="ID_1946341214" CREATED="1745516272054" MODIFIED="1745516282840"/>
<node TEXT="Ice Cubes" ID="ID_1907972674" CREATED="1745516283655" MODIFIED="1745516304921"/>
<node TEXT="Mona" ID="ID_1373997498" CREATED="1745516313008" MODIFIED="1745516315257"/>
<node TEXT="Offizielle Mastodon-App" ID="ID_1748907448" CREATED="1745516315696" MODIFIED="1745516322641"/>
</node>
<node TEXT="Web-Anwendungen" ID="ID_776251742" CREATED="1745515431374" MODIFIED="1745515486537">
<node TEXT="z.B. Mastodeck, was gut aussieht, aber ..." ID="ID_1741172558" CREATED="1745515487280" MODIFIED="1745515536360"/>
<node TEXT="benötigen Zugriff auf Account" ID="ID_1810700996" CREATED="1745515490552" MODIFIED="1745515521239">
<icon BUILTIN="smily_bad"/>
</node>
</node>
</node>
<node TEXT="Schutzmaßnahmen&#xa;am Beispiel Mastodon" POSITION="bottom_or_right" ID="ID_1220332744" CREATED="1744981552455" MODIFIED="1745500587106">
<node TEXT="Inhaltswarnungen" ID="ID_1523330193" CREATED="1744981566188" MODIFIED="1744981603303">
<node TEXT="Bei eigenene Postings deren Inhalt andere (ver)stören/verletzen/... könnte" ID="ID_1349382" CREATED="1744981603830" MODIFIED="1744981636992"/>
<node TEXT="Entscheidung ob Default-Anzeige oder nicht in den eigenen Einstellungen" ID="ID_351857131" CREATED="1744981638135" MODIFIED="1744981662745"/>
</node>
<node TEXT="Für sich selbst" ID="ID_1377873739" CREATED="1745500126944" MODIFIED="1745500137778">
<node TEXT="Account via 2FA (TOTP) absichern" ID="ID_393697643" CREATED="1745500138249" MODIFIED="1745500150002"/>
<node TEXT="Follower autom. akzeptieren deaktivieren?" ID="ID_4903104" CREATED="1745500361537" MODIFIED="1745500374115"/>
<node TEXT="Privatsphären-Einstellungen wie Follower anzeigen, Client-Software anzeigen, Suchmaschinen-Einstellungen, ..." ID="ID_1107328544" CREATED="1745500391514" MODIFIED="1745500539129"/>
<node TEXT="Account-Listen deren Beiträge nicht auf die Startseite kommen" ID="ID_1564893513" CREATED="1745513867498" MODIFIED="1745513910065" LINK="https://gnulinux.ch/unangenehme-inhalte-vermeiden"/>
</node>
</node>
<node TEXT="Eigene Anwendungen für das / auf Basis des Fediverse" POSITION="bottom_or_right" ID="ID_1814882873" CREATED="1745508917625" MODIFIED="1745510227968">
<node TEXT="ActivityPub eBook, Evan Prodromou,&#xa;O&apos;Reilly, 2024, ISBN 9781098169466" ID="ID_806522644" CREATED="1745508932314" MODIFIED="1745510306548" LINK="https://www.oreilly.com/library/view/activitypub/9781098162733/"/>
<node TEXT="Kuratierte Liste von Ressourcen für ActivityPub-Entwickler - Codeberg" ID="ID_414557381" CREATED="1745510069876" MODIFIED="1745510090609" LINK="https://codeberg.org/fediverse/delightful-activitypub-development"/>
<node TEXT="Mastodon: Getting started with the API" ID="ID_1126060701" CREATED="1745515254535" MODIFIED="1745515281357" LINK="https://docs.joinmastodon.org/client/intro/"/>
</node>
<node TEXT="Konferenzen, Meetings, Fortbildungen, Unterricht, ..." POSITION="bottom_or_right" ID="ID_1416980634" CREATED="1745510106693" MODIFIED="1745510609513">
<node TEXT="Wie üblich vor Veranstaltung den Hash-Tag vorgeben / prägen, z.B. #LIT2025, #Linuxinfotag, #LUGA" ID="ID_992832545" CREATED="1745510490643" MODIFIED="1745510573000"/>
<node TEXT="Mastowall auf Basis von Hashtags der Veranstaltung" POSITION="bottom_or_right" ID="ID_516986575" CREATED="1745499142915" MODIFIED="1745510130718" LINK="https://rstockm.github.io/mastowall/?hashtags=lit2025,linuxinfotag2025,luga&amp;server=https://mastodon.social"/>
</node>
</node>
</map>
